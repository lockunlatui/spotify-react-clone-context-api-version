import { Images } from "@utils/index";


console.log("Images", Images);

const boxMusic: any = [
  {
    id: `1`,
    img: Images["BOXMUSIC1"],
    title: "LUMBERJACK",
    subtitle: `Tyler, The Creator`,
  },
  {
    id: `2`,
    img:  Images["BOXMUSIC2"],
    title: "LUMBERJACK",
    subtitle: `Tyler, The Creator`,
  },
  {
    id: `3`,
    img: Images["BOXMUSIC3"],
    title: "LUMBERJACK",
    subtitle: `Tyler, The Creator`,
  },
  {
    id: `4`,
    img: Images["BOXMUSIC4"],
    title: "LUMBERJACK",
    subtitle: `Tyler, The Creator`,
  },
  {
    id: `5`,
    img: Images["BOXMUSIC5"],
    title: "LUMBERJACK",
    subtitle: `Tyler, The Creator`,
  },
  {
    id: `6`,
    img: Images["BOXMUSIC6"],
    title: "LUMBERJACK",
    subtitle: `Tyler, The Creator`,
  },
];

export { boxMusic };
