import LookingForMusic from "./LookingForMusic";

const IntroductionMain = () => {
  return (
    <section>
      <LookingForMusic />
    </section>
  );
};

export default IntroductionMain;
