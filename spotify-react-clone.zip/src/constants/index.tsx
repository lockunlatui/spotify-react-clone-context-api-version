import { Colors } from "./Colors";

export { Colors };
