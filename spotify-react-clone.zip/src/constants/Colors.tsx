export const Colors = {
  green: "#1ed760",
  white: '#FFFFFF'
};
