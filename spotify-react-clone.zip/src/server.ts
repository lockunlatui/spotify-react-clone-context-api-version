import express, { Request } from 'express';
import cors from 'cors';
import passport from 'passport';
import session from 'express-session';
import { Strategy } from 'passport-spotify';
import { UsersDAO } from '../api/dao';

export interface Profile {
  provider: string;
  id: string;
  username: string;
  displayName: string;
  profileUrl: string | null;
  photos: [string] | null;
  country: string;
  followers: number | null;
  product: string | null;
  emails?: [{ value: string; type: null }];
  _raw: string;
  _json: any;
}

export type VerifyCallback = (
  error?: Error | null,
  user?: object,
  info?: object
) => void;

export type VerifyFunction = (
  accessToken: string,
  refreshToken: string,
  expires_in: number,
  profile: Profile,
  done: VerifyCallback
) => void;

const client_id = '7135678f0c4a44639b6183352c5a523d';
const client_secret = '7f2a4bd1d5934c4c974a4ec603c59434';
const redirect_uri = '/api/v1/auth/spotify/callback';

const app = express();
app.use(cors());

passport.use(
  new Strategy(
    {
      clientID: client_id,
      clientSecret: client_secret,
      callbackURL: redirect_uri,
      passReqToCallback: true,
    },
    function (
      req: Request,
      accessToken: string,
      refreshToken: string,
      expires_in: number,
      profile: Profile,
      done: VerifyCallback
    ) {
      process.nextTick(function () {
        return done(null, profile);
      });
    }
  )
);

passport.serializeUser(function (user, done) {
  done(null, user);
});

passport.deserializeUser(function (obj: any, done) {
  done(null, obj);
});

app.use(session({ secret: 'whoami', resave: true, saveUninitialized: true }));

app.use(passport.initialize());
app.use(passport.session());

app.get(
  '/api/v1/auth/spotify',
  passport.authenticate('spotify', {
    scope: ['user-read-email', 'user-read-private'],
  })
);
app.get(
  '/api/v1/auth/spotify/callback',
  passport.authenticate('spotify', { failureRedirect: '/' }),
  function (req, res) {
    res.redirect('http://localhost:3000');
  }
);

app.get('/api/v1/me', ensureAuthenticated, async function (req, res, next) {
  if (req.isAuthenticated()) {
    const user = await UsersDAO.getUser('21pksbjbzmp3y33ev7rrapo6y');
    const data = {
      country: user.country,
      displayName: user.displayName,
      email: user.emails[0].value,
      followers: user.followers,
      id: user.id,
      photo: user.photos[0].value,
      product: user.product,
      profileUrl: user.profileUrl,
    }
    res.send(data).status(200);
  } else {
    res.send({
      status: 401,
    });
  }
});

app.get('/api/v1/logout', function (req, res) {
  req.logout();
  res.redirect('/');
});

function ensureAuthenticated(req: any, res: any, next: any) {
  console.log('=> isAuthenticated', req.isAuthenticated());
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401);
  return next();
}

export default app;
