import { Request } from 'express';
import passport from 'passport';
import { Strategy } from 'passport-spotify';

const client_id = '7135678f0c4a44639b6183352c5a523d';
const client_secret = '7f2a4bd1d5934c4c974a4ec603c59434';
const redirect_uri = '/api/v1/auth/spotify/callback';

let users: any;

export interface Profile {
  provider: string;
  id: string;
  username: string;
  displayName: string;
  profileUrl: string | null;
  photos: [string] | null;
  country: string;
  followers: number | null;
  product: string | null;
  emails?: [{ value: string; type: null }];
  _raw: string;
  _json: any;
}

export type VerifyCallback = (
  error?: Error | null,
  user?: object,
  info?: object
) => void;

export type VerifyFunction = (
  accessToken: string,
  refreshToken: string,
  expires_in: number,
  profile: Profile,
  done: VerifyCallback
) => void;

class UsersDAO {
  static async injectDB(conn: any) {
    if (users) {
      return;
    }
    try {
      users = await conn.db(process.env.DATABASE_NAME).collection('users');
    } catch (error) {
      console.log(`connect db and collection users: ${error}`);
    }
  }

  static async addUser() {
    const query = { username: '21pksbjbzmp3y33ev7rrapo6y' };
    const user = await users.findOne(query);
    if (user.username !== '21pksbjbzmp3y33ev7rrapo6y') {
      passport.use(
        new Strategy(
          {
            clientID: client_id,
            clientSecret: client_secret,
            callbackURL: redirect_uri,
            passReqToCallback: true,
          },
          function (
            req: Request,
            accessToken: string,
            refreshToken: string,
            expires_in: number,
            profile: Profile,
            done: VerifyCallback
          ) {
            process.nextTick(function () {
              users.insertOne(profile);
              return done(null, profile);
            });
          }
        )
      );
    }
  }

  static async getUser(userId: string) {
    const query = { username: userId };
    const user = await users.findOne(query);
    return user;
  }
}

export default UsersDAO;
